# LinguaQuest Complete

Complete online Flask version of LinguaQuest.

## Included
- Online signup/login with Flask sessions and SQLite
- Student profile
- Subject learning quizzes
- Multiple languages
- Calculator
- Notes
- Exam countdown
- Weekly study planner (Monday-Saturday)
- Level & XP
- Study Time timer
- Habit Tracker with XP
- Focus Session with XP
- Healthy Student tracking (sleep, water, exercise, meditation)
- Sports Training (boxing fitness, calisthenics, running, cycling)
- Gemini 2.5 Flash AI Student Assistant
- Student feedback with ratings

## Run
1. Create a virtual environment (recommended).
2. Install dependencies:
   `pip install -r requirements.txt`
3. Set your Gemini API key as an environment variable:
   Windows PowerShell: `$env:GEMINI_API_KEY="YOUR_KEY"`
4. Start Flask:
   `python app.py`
5. Open `http://127.0.0.1:5000`

The Gemini API key belongs on the server and should not be put into the HTML.
